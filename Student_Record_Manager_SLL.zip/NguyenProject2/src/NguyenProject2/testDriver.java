/**
 * Programmer: Daniel Nguyen
 * Course: COSC 311, W '24
 * testDriver class that creates a student database using a menu-based program
 */
package NguyenProject2;

import java.util.*;
import java.io.*;

public class testDriver {
	private static Scanner keyboard = new Scanner (System.in);
	private static Scanner read;
	private static RandomAccessFile randFile;
	private static File file;
	private static OrderedSinglyLinkedList<Pair<Integer>> stuList;
	private static final int RECSIZE = 92;
	private static boolean builtIndex = false;

	public static void main(String[] args) throws IOException {
		heading();
		printMenu();
		int choice = keyboard.nextInt();
		while (choice > 0 && choice < 9) {
			menuOptions(choice);
			printMenu();
			choice = keyboard.nextInt();
			if (choice < 0 || choice > 9) {
				System.out.println("Invalid option. Choose again");
				choice = keyboard.nextInt();
			}
		}
	}
	
	public static void menuOptions (int choice) throws IOException{
		try {
			switch(choice) {
				case 1: //Build RandomAccessFile
					System.out.print("Enter an input file name: ");
					String fileNameInput = keyboard.next();
					file = new File (fileNameInput);
					read = new Scanner (file);
					System.out.print("Enter an output file name: ");
					String randomAFNameInput = keyboard.next();
					file = new File (randomAFNameInput);
					randFile = new RandomAccessFile (file, "rw");
					buildRandFile();
					break;
					
				case 2: //Display RandomAccessFile
					if (randFile == null) {
						System.out.println("Create the RandomAccessFile first");
						break;
					}
					System.out.print("Enter the RandomAccessFile name: ");
					String randFileName = keyboard.next();
					randFile = new RandomAccessFile (randFileName, "rw");
					displayRandFile();
					break;
					
				case 3: //Build the index
					System.out.print("Enter the RandomAccessFile name: ");
					randFileName = keyboard.next();
					//randFile = new RandomAccessFile (randFileName, "rw");
					buildIndex();
					break;
					
				case 4: //Display the index
					if (builtIndex == false) {
						System.out.println("Build the index first!");
						break;
					}
					else {
						System.out.print("Enter the starting ID, or -1 to show the entire index: ");
						int startingID = keyboard.nextInt();
						displayIndex(startingID);
						break;
					}
					
				case 5: //Retrieve a record
					if (builtIndex == false) {
						System.out.println("Build the index first!");
						break;
					}
					else {
						System.out.print("Enter a student ID: ");
						int numID = keyboard.nextInt();
						retrieveRecord(numID);
						break;
					}
					
				case 6: //Modify a record
					if (builtIndex == false) {
						System.out.println("Build the index first!");
						break;
					}
					else {
						System.out.print("Enter a student ID: ");
						int studID = keyboard.nextInt();
						modifyRecord(studID);
						break;
					}
				
				case 7: //Add a new record
					if (builtIndex == false) {
						System.out.println("Build the index first!");
						break;
					}
					else {
						System.out.print("Enter first name: ");
						String fName = keyboard.next();
						System.out.print("Enter last name: ");
						String lName = keyboard.next();
						System.out.print("Enter student ID: ");
						int studentID = keyboard.nextInt();
						System.out.print("Enter GPA: ");
						double studentGPA = keyboard.nextDouble();
						addRecord(fName, lName, studentID, studentGPA);
						break;
					}
					
				case 8: //Delete a record
					if (builtIndex == false) {
						System.out.println("Build the index first!");
						break;
					}
					else {
						System.out.print("Enter a student ID: ");
						int stuID = keyboard.nextInt();
						deleteRecord(stuID);
					}
			}
		}
		catch (InputMismatchException ex) {
			System.out.println(ex.getMessage());
		}
		catch (FileNotFoundException ex) {
			System.out.println(ex.getMessage());
		}
		catch (IOException ex) {
			System.out.println(ex.getMessage());
		}
	}
	
	public static void heading() {
 		System.out.println("Programmer:        Daniel Nguyen");
 		System.out.println("Course:            COSC 311, W '24	");
 		System.out.println("Project:           1");
 		System.out.println("Due date:          2-20-24\n");
 	}
	
	public static void printMenu() {
        System.out.println("\n   Menu   ");
        System.out.println("   ====");
        System.out.println("1: Make a random-access file");
        System.out.println("2: Display a random-access file");
        System.out.println("3: Build the index");
        System.out.println("4: Display the index");
        System.out.println("5: Retrieve a record");
        System.out.println("6: Modify a record");
        System.out.println("7: Add a new record");
        System.out.println("8: Delete a record");
        System.out.println("9: Exit");
        
        System.out.print("\nEnter your choice: ");
    }
	
	/*
	 * Builds a random-access file by sending in a text document 
	 */
	public static void buildRandFile() throws IOException {
		Student stu = new Student();
		while (read.hasNext()) {
			stu.readFromTextFile(read);
			stu.writeToFile(randFile);
		}
		System.out.println("RandomAccessFile successfully created");
	}
	
	/*
	 * Displays the random-access file if it exists
	 */
	public static void displayRandFile() throws IOException {
		Student stu = new Student();
		int counter = 0;
		try {
			//Starts at the beginning of the file
	        randFile.seek(0);
	        //Searches until the end of the file
	        while (randFile.getFilePointer() < randFile.length()) {
	            stu.readFromFile(randFile);
	            //Checks if a record as been "deleted". Prints the record if it isn't
	            if (!stu.getFirst().trim().equals("DELETED")) {
	                System.out.println(stu);
	                counter++;
	            }
	            //if counter reaches five, stop printing records and asks for options
	            //If N is entered, reset counter to 5
	            if (counter == 5) {
	                System.out.print("Enter N (for next five records), A for all remaining records, or M for main menu: ");
	                String choice = keyboard.next();
	                if (choice.toUpperCase().equals("N")) {
	                    counter = 0;
	                }
	                //If A is entered, just have the loop continue 
	                else if (choice.toUpperCase().equals("A")) {
	                    while (randFile.getFilePointer() < randFile.length()) {
	                        stu.readFromFile(randFile);
	                        if (!stu.getFirst().trim().equals("DELETED")) {
	                            System.out.println(stu);
	                        }
	                    }
	                    break;
	                }
	                else {
	                    break;
	                }
	            }
	        }
	    }
	    catch (IOException ex) {
	        System.out.println("Display RandomAccessFile failed due to IOException: " + ex.getMessage());
	    }
	}
	
	public static void buildIndex() throws IOException {
		Student stu = new Student();
		//Creates and sets stuList as an OrderedSinglyLinkedList
		stuList = new OrderedSinglyLinkedList <Pair<Integer>>();
		try {
			//Starts at the beginning of the file
			randFile.seek(0);
	        while (randFile.getFilePointer() < randFile.length()) {
	        	//get the position of the file pointer so we can use it to assign the address of the student
	        	//in the Pair
	        	int position = (int) randFile.getFilePointer();
	            stu.readFromFile(randFile);
	            //Checks if we reached the end of the file. Breaks out of the loop if so
	            if (stu.getFirst() == null) {
	                break; 
	            }
	            //Creates a pair of the current student being read by in the file using their ID and address in the file
	            Pair<Integer> stuPair = new Pair<>(stu.getID(), position);
	            stuList.add(stuPair);
	        }
	        //boolean variable created in the class. Is used to check if an index has been created
	        builtIndex = true;
	        System.out.println("Index successfully built");
	    } 
		catch (IOException ex) {
	        System.out.println("Index not built due to IOException: " + ex.getMessage());
	    }
	}
	
	public static void displayIndex(int startingID) throws IOException{
		//If -1 is entered to check all Indexes
		if (startingID == -1) {
			for (Pair<Integer> pair: stuList) {
				//Recsize is used since the actual position between each record is 92
				//This is mainly just to show which ID comes first in the index by giving them
				//smaller numbers like 0, 1, 2, etc.
				int position = pair.getSecond() / RECSIZE; 
				System.out.println(pair.getFirst() + "\t" + position);
			}
		}
		else {
			//Gains the index where the entered student ID is.
			int index = stuList.indexOf(new Pair<>(startingID, null));
			//if index is not -1, it means it is in the list
			if (index != -1) {
				//starting from the index where the Pair is to the end of the list
				//prints out the index from that student ID 
				for (int i = index; i < stuList.size(); i++) {
					Pair<Integer> stuPair = stuList.get(i);
					int position = stuPair.getSecond() / RECSIZE;
					System.out.println(stuPair.getFirst() + "\t" + position);
				}
			}
			else {
				System.out.println(startingID + " is an invalid ID");
			}
		}
	}
	
	public static void retrieveRecord(int numID) throws IOException {
		//searches for the index of the entered ID
		int index = stuList.indexOf(new Pair<>(numID, null));
		Student stu = new Student();
		//Checks if ID exist in the list
		if (index != -1) {
			//if it exists, get the position and seek the randFile from that position
			int position = stuList.get(index).getSecond();
		    randFile.seek(position); 
		    //read the record on the position and prints it
			stu.readFromFile(randFile);
			System.out.println(stu);
		}
		else {
			System.out.println(numID + " is an invalid ID");
		}
	}
	
	public static void modifyRecord(int studID) throws IOException {
		int index = stuList.indexOf(new Pair<> (studID, null));
		Student stu = new Student();
		if (index != -1) {
			int position = stuList.get(index).getSecond();
			randFile.seek(position);
			stu.readFromFile(randFile);
			printModOptions();
			int selection = keyboard.nextInt();
			//while loop that modifies the record until 4 is selected
			while (selection > 0 && selection < 4) {
				switch (selection) {
					case 1: //Change first name
						System.out.print("Enter first name: ");
						String firstN = keyboard.next();
						stu.setFirst(firstN);
						break;
						
					case 2: //Change last name
						System.out.print("Enter last name: ");
						String lastN = keyboard.next();
						stu.setLast(lastN);
						break;
						
					case 3: //Change GPA
						System.out.print("Enter GPA: ");
						double GPA = keyboard.nextDouble();
						stu.setGPA(GPA);
						break;
					
					case 4: //Done
						break;
				}
				printModOptions();
				selection = keyboard.nextInt();
			}
			//seek method is used here to seek back to the position of the record being modified
			//This is so the writeToFile method can overwrite the record being modifed rather than
			//add it at the end
			randFile.seek(position);
			stu.writeToFile(randFile);
		}
		else {
			System.out.println(studID + " is an invalid ID");
		}
	}
	
	public static void addRecord(String fName, String lName, int studentID, double studentGPA) throws IOException {
		//Checks if student ID exists. It exists if the index is not -1
		if (stuList.indexOf(new Pair<>(studentID, null)) != -1) {
			System.out.println("Student ID already exists");
		}
		else {
			//Gets the position at the end of the file
			int position = (int) randFile.length();
			randFile.seek(position);
			Student newStu = new Student();
			//Create a new student, add it into the file, and add it to the index
			newStu.setData(fName, lName, studentID, studentGPA);
			newStu.writeToFile(randFile);
			Pair<Integer> newStuPair = new Pair<>(studentID, (int) position);
			stuList.add(newStuPair);
		}
	}
	
	public static void deleteRecord(int stuID) throws IOException {
		int index = stuList.indexOf(new Pair<> (stuID, null));
		Student stu = new Student();
		if (index != -1) {
			int position = stuList.get(index).getSecond();
			randFile.seek(position);
			stu.readFromFile(randFile);
			stu.setFirst("DELETED");
			randFile.seek(position);
			stu.writeToFile(randFile);
			stuList.remove(index);
		}
		else {
			System.out.println(stuID + " is not an existing ID");
		}
	}
	
	private static void printModOptions() {
		System.out.println();
		System.out.println("1: Change First Name: ");
        System.out.println("2: Change Last Name: ");
        System.out.println("3: Change GPA: ");
        System.out.println("4: Finish");
        System.out.print("Enter your choice: ");
	}
}
