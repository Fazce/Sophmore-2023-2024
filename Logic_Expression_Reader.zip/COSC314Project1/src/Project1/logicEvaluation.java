//Daniel Nguyen
//COSC314 Project 1
package Project1;

import java.util.*;

public class logicEvaluation {
	public static void main(String[] args) {
		Scanner in = new Scanner (System.in);
		System.out.println("Logical Expression Evaluator");
		System.out.println("------------------------------");
		System.out.print("Enter the number of variables in the expression: ");
		int varCount = in.nextInt();
		//NextLine needed to consume a line. I put it here 
		//since it was the simplest solution I had when truth values were being mislabeled 
		in.nextLine();
		
		boolean[] truthVals = new boolean[varCount];
		System.out.println("Enter the values of variables - true or false:");
        for (char var = 'a'; var < 'a' + varCount; var++) {
            System.out.print(var + ": ");
            String value = in.nextLine();
            //While statement that checks if the input is true or false
            while (!value.equalsIgnoreCase("true") && !value.equalsIgnoreCase("false")) {
        		System.out.println("Invalid. Please put true or false");
        		value = in.nextLine(); 
        	}
            truthVals[var - 'a'] = Boolean.parseBoolean(value);
        }
        
        System.out.println("Enter a logical expression: ");
        String express = in.nextLine();
        boolean answer = removeSpaces(express, truthVals);
        System.out.println("The value of the expression is: " + answer);
	}
	
	//boolean method that removes all spaces in the expression. 
	public static boolean removeSpaces(String express, boolean[] truthVals) {
		express = express.replaceAll("\\s+", "");
		//sends the expression with no spaces to evalExpress
		return evalExpress (express, truthVals);
	}
	
	//recursive boolean method that reads the expression from left to right
	public static boolean evalExpress(String express, boolean[] truthVals) {
		//Debug output statement
//		System.out.println("Evaluating expression: " + express);
		
		if (express.contains("/\\")) {
	        int andIndex = express.indexOf("/\\");
	        String expressLeft = express.substring(0, andIndex);
	        String expressRight = express.substring(andIndex + 2); //+ 2 is necessary to skip pass the rest of the AND
	        //debugging messages
//	        boolean debugLeftResult = evalExpress(expressLeft, truthVals);
//	        boolean debugRightResult = evalExpress(expressRight, truthVals);
//	        boolean debugResult = debugLeftResult && debugRightResult;
//	        System.out.println("AND result: " + debugResult);
	        return evalExpress(expressLeft, truthVals) && evalExpress(expressRight, truthVals);
	    } 
		
		else if (express.contains("\\/")) {
	        int orIndex = express.indexOf("\\/");
	        String expressLeft = express.substring(0, orIndex);
	        String expressRight = express.substring(orIndex + 2); //+2 necessary to skip the rest of OR
	        //debugging messages
//	        boolean debugLeftResult = evalExpress(expressLeft, truthVals);
//	        boolean debugRightResult = evalExpress(expressRight, truthVals);
//	        boolean debugResult = debugLeftResult && debugRightResult;
//	        System.out.println("OR result: " + debugResult);
	        return evalExpress(expressLeft, truthVals) || evalExpress(expressRight, truthVals);
	    } 
		
		else if (express.startsWith("~")) {
//			 boolean debugResult = !evalExpress(express.substring(1), truthVals);
//		     System.out.println("Negation result: " + debugResult);
	        return !evalExpress(express.substring(1), truthVals);
	    } 
		
		else {
	        char var = express.charAt(0);
	        //debug that checks the truth value of a variable
//	        boolean result = truthVals[var - 'a'];
//	        System.out.println("Variable " + var + " result: " + result);
	        return truthVals[var - 'a'];
	    }
	}
}