/**
 * A partial implementation of a hash table using chaining (binary search trees)
 *
 *  @author COSC 311, Winter '24
 *  @version (3-12-24)
 *  
 *  Note: You must add methods get, and remove to this class. Also, you must 
 *        replace the call to the preOrder method with a call to the levelOrder method
 *        which you will add to the class BST.
 */
package Nguyen_project5;

//Write a get and remove method for the Hashing method

public class Hashing <K extends Comparable <K>, V>{
	private final int SIZE= 37;
	private BST<Pair<K,V>> [] table;
	
	// constructor 
	public Hashing () {
		//table = (BST<Pair<K,V>> [])new Object [SIZE];  //*** this doesn't work!
		table = new BST[SIZE];
	}

	// hash the key using division  (replace this hash function whit the one given)
	public int hash(K key) {
		int keyInt = (Integer) key;
		return ((keyInt*keyInt) >>> 10) % SIZE;
	}
	
	// add a (key,value) pair into the hash table, make sure this method works!
	public V put (K key , V value) {
		int index = hash(key);
		if (index < 0) index += table.length;
		if (table[index] == null) table[index] = new BST<Pair<K,V>> ();
		Pair <K,V> item = new Pair<>(key,value);
		Pair<K,V> other = table[index].find(item);
		if (other == null) {   // item isn't in the table
			table[index].add(item);
			return null;
		}
		// an item with the given key is in the table
		table[index].replace(other,item);
		return other.getValue();
	}	
	
	// Gets the value of a (key, value) pair by searching for the key. Returns the value if key isn't null
	public V get (K key) {
		int index = hash(key);
		if (index < 0) {
			index += table.length;
		}
		//if the key is valid
		if (table[index] != null) {
			Pair<K, V> pair = new Pair<>(key, null);
			Pair<K, V> foundPair = table[index].find(pair);
			//If the BST contains the (key, value) pair, returns the value
			if (foundPair != null) {
				return foundPair.getValue();
			}
		}
		//Key not found. Returns null
		return null;
	}
	
	//Returns the removed value of a removed (key, value) pair by searching its key
	//Based off of the remove algorithm in the textbook with slight modifications
	public V remove (K key) {
		int index = hash(key);
		if (index < 0) {
			index += table.length;
		}
		Pair<K, V> pair = new Pair<>(key, null);
		//If the key wasn't found
		if (table[index] == null) {
			return null;
		}
		//If the key was found, get the value that is about to be removed, and then delete the pair from the table
		else {
			V removedValue = table[index].find(pair).getValue();
			//Deletes the (key, value) pair from the Binary Tree
			table[index].delete(pair);
			//Set to null in order to remove the pair from the hash table
			table[index] = null;
			return removedValue;
		}
	}
	
	// print the hash table using preorder traversal of BSTs
	public void print() {
		for (int i=0;i<SIZE;i++)
			if (table[i] != null) {
				System.out.print(i + ": ");
				table[i].BFS(null);
			}
	}
	
	// Another print method that allows for the hash table to be printed between certain indexes
	public void print(int start, int end) {
		for (int i = start; i < end+1; i++) {
			if (table[i] != null) {
				System.out.print(i + ": ");
				table[i].BFS(null);
			}
		}
	}
}
