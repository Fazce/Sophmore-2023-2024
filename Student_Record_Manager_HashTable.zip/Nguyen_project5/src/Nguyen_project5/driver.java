/**
 * Programmer: Daniel Nguyen
 * Course: COSC 311, W '24
 * driver class for Project 5 where a student database is created via a menu driven program
 * The databases uses a HashTable to create an index for the student records
 */
package Nguyen_project5;

import java.io.*;
import java.util.*;

public class driver {
	//private static variables made within the class to be used in the class' methods
		private static Scanner keyboard = new Scanner (System.in);
		private static Scanner read;
		private static RandomAccessFile randFile;
		private static File file;
		private static Hashing<Integer, Integer> hashTable;
		private static final int RECSIZE = 92;
		private static boolean builtIndex = false;
		//Main method that initiates the program
		//try-catch block to catch if the user inputs a non-integer value for the menu
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		heading();
		printMenu();
		int choice = 0;
		while (choice != 9) {
			try {
				choice = keyboard.nextInt();
				while (choice > 0 && choice < 9) {
					menuOptions(choice);
					printMenu();
					choice = keyboard.nextInt();
					if (choice < 0 || choice > 9) {
						System.out.println("Invalid option. Choose again");
						choice = keyboard.nextInt();
					}
				}
				//displayHashTable();
				randFile.close();
			}
			catch (InputMismatchException ex) {
				System.out.println("Not an integer. Please enter an integer: ");
				//nextLine() needed to skip to the next line and prevent the program from endlessly looping
				keyboard.nextLine();
				choice = 0;
			}
		}
	}
	
	/**
	 * Method that contains the handling of operations used in the program
	 * @param choice
	 * @return none
	 * @throws IOException
	 */
	public static void menuOptions (int choice) throws IOException {
		try {
			switch(choice) {
				case 1: //Build RandomAccessFile
					System.out.print("Enter an input file name: ");
					String fileNameInput = keyboard.next();
					file = new File (fileNameInput);
					read = new Scanner (file);
					System.out.print("Enter an output file name: ");
					String randomAFNameInput = keyboard.next();
					file = new File (randomAFNameInput);
					//Checks if a RandomAccessFile of the same name exists. Deletes the file if it does
					//Essentially acts as a way of overwriting a file of the same name
					if (file.exists()) {
						file.delete();
					}
					randFile = new RandomAccessFile (file, "rw");
					buildRandFile();
					break;
					
				case 2: //Display RandomAccessFile
					String randFileName;
					System.out.print("Enter the RandomAccessFile name: ");
					randFileName = keyboard.next();
					file = new File (randFileName);
					//Checks if the RandomAccessFile of the input name exist.
					//Displays the file if it exist. Else it asks the user to make the file
					if (file.exists()) {
						randFile = new RandomAccessFile (randFileName, "rw");
						displayRandFile();
						break;
					}
					else {
						System.out.println("Create the RandomAccessFile first");
						break;
					}
					
				case 3: //Build the index
					System.out.print("Enter the RandomAccessFile name: ");
					randFileName = keyboard.next();
					file = new File (randFileName);
					//Checks if the RandomAccessFile of the input name exist.
					//Creates an index for that file if it exist. Else it tells the user it doesn't exist
					if (file.exists()) {
						randFile = new RandomAccessFile (randFileName, "rw");
						buildIndex();
						break;
					}
					else {
						System.out.println("RandomAccessFile does not exist");
						break;
					}
					
				case 4: //Display the index
					if (builtIndex == false) {
						System.out.println("Build the index first!");
						break;
					}
					else {
						//keyboard.nextLine() needed to start new line to prevent conflict due to next() being used
						keyboard.nextLine();
						int startingIndex = 0;
						int endingIndex = 36;
						System.out.print("Enter the starting index (0-36): ");
						String startIndex = keyboard.nextLine();
						if (!startIndex.isEmpty()) {
							startingIndex = Integer.parseInt(startIndex);
						}
						System.out.print("Enter the ending index (0-36): ");
						String endIndex = keyboard.nextLine();
						if (!endIndex.isEmpty()) {
							endingIndex = Integer.parseInt(endIndex);
						}
						displayIndex(startingIndex, endingIndex);
						break;
					}
					
				case 5: //Retrieve a record
					if (builtIndex == false) {
						System.out.println("Build the index first!");
						break;
					}
					else {
						System.out.print("Enter a student ID: ");
						int numID = keyboard.nextInt();
						retrieveRecord(numID);
						break;
					}
					
				case 6: //Modify a record
					if (builtIndex == false) {
						System.out.println("Build the index first!");
						break;
					}
					else {
						System.out.print("Enter a student ID: ");
						int studID = keyboard.nextInt();
						modifyRecord(studID);
						break;
					}
				
				case 7: //Add a new record
					if (builtIndex == false) {
						System.out.println("Build the index first!");
						break;
					}
					else {
						System.out.print("Enter first name: ");
						String fName = keyboard.next();
						System.out.print("Enter last name: ");
						String lName = keyboard.next();
						System.out.print("Enter student ID: ");
						int studentID = keyboard.nextInt();
						System.out.print("Enter GPA: ");
						double studentGPA = keyboard.nextDouble();
						addRecord(fName, lName, studentID, studentGPA);
						break;
					}
					
				case 8: //Delete a record
					if (builtIndex == false) {
						System.out.println("Build the index first!");
						break;
					}
					else {
						System.out.print("Enter a student ID: ");
						int stuID = keyboard.nextInt();
						deleteRecord(stuID);
					}
			}
		}
		catch (NumberFormatException ex) {
			System.out.println("Invalid input: An input in the current menu option is not valid");
		}
		catch (FileNotFoundException ex) {
			System.out.println(ex.getMessage());
		}
		catch (IOException ex) {
			System.out.println(ex.getMessage());
		}
	}
	
	/**
	 * Just a method to print out the heading
	 * @param none
	 * @return none
	 */
	public static void heading() {
 		System.out.println("Programmer:        Daniel Nguyen");
 		System.out.println("Course:            COSC 311, W '24	");
 		System.out.println("Project:           5");
 		System.out.println("Due date:          4-16-24\n");
 	}
	
	/**
	 * Prints the menu options of the program in the console
	 * @param none
	 * @return none
	 */
	public static void printMenu() {
        System.out.println("\n   Menu   ");
        System.out.println("   ====");
        System.out.println("1: Make a random-access file");
        System.out.println("2: Display a random-access file");
        System.out.println("3: Build the index");
        System.out.println("4: Display the index");
        System.out.println("5: Retrieve a record");
        System.out.println("6: Modify a record");
        System.out.println("7: Add a new record");
        System.out.println("8: Delete a record");
        System.out.println("9: Exit");
        
        System.out.print("\nEnter your choice: ");
    }
	
	/**
	 * Creates a new RandomAccessFile when called to, assuming that a text file exists
	 * @param none
	 * @return none
	 * @throws IOException
	 */
	public static void buildRandFile() throws IOException {
		Student stu = new Student();
		while (read.hasNext()) {
			stu.readFromTextFile(read);
			stu.writeToFile(randFile);
		}
		System.out.println("RandomAccessFile successfully created");
	}
	
	/**
	 * Displays a RandomAccessFile when called to if the RandomAccessFile exists
	 * @param none
	 * @return none
	 * @throws IOException
	 */
	public static void displayRandFile() throws IOException {
		Student stu = new Student();
		int counter = 0;
		try {
			//Starts at the beginning of the file
	        randFile.seek(0);
	        //Searches until the end of the file
	        while (randFile.getFilePointer() < randFile.length()) {
	            stu.readFromFile(randFile);
	            //Checks if a record as been "deleted". Prints the record if it isn't
	            if (!stu.getFirst().trim().equals("DELETED")) {
	                System.out.println(stu);
	                counter++;
	            }
	            //if counter reaches five, stop printing records and asks for options
	            //If N is entered, reset counter to 5
	            if (counter == 5) {
	                System.out.print("Enter N (for next five records), A for all remaining records, or M for main menu: ");
	                String choice = keyboard.next();
	                if (choice.toUpperCase().equals("N")) {
	                    counter = 0;
	                }
	                //If A is entered, just have the loop continue 
	                else if (choice.toUpperCase().equals("A")) {
	                    while (randFile.getFilePointer() < randFile.length()) {
	                        stu.readFromFile(randFile);
	                        if (!stu.getFirst().trim().equals("DELETED")) {
	                            System.out.println(stu);
	                        }
	                    }
	                    break;
	                }
	                else {
	                    break;
	                }
	            }
	        }
	    }
	    catch (IOException ex) {
	        System.out.println("Display RandomAccessFile failed due to IOException: " + ex.getMessage());
	    }
	}
	
	/**
	 * Method that builds a Hash Table index for a RandomAccessFile
	 * @param none
	 * @return none
	 * @throws IOException
	 */
	public static void buildIndex () throws IOException {
		Student stu = new Student();
		hashTable = new Hashing<Integer, Integer>();
		try {
			randFile.seek(0);
			while (randFile.getFilePointer() < randFile.length()) {
				int position = (int) randFile.getFilePointer();
				stu.readFromFile(randFile);
				//Checks if the while loop has reached the end of the file
				if(stu.getFirst() == null) {
					break;
				}
				//Else if statement that checks if a record is deleted. If so, do not add it in the index and continue
				//Will only be reached if running the program a second time with a RandomAccessFile containing a deleted record
				else if (stu.getFirst().trim().equals("DELETED")){
					continue;
				}
				//Pair created for the student with this ID and the position they are on the list
				//Not needed for the program, but is used to make it easier for me to understand and remember
				Pair<Integer, Integer> stuPair = new Pair<Integer, Integer>(stu.getID(), position / RECSIZE);
				//Puts the (key, value) pair into the hashTable. With how put is coded, the key will be hashed
				hashTable.put(stuPair.getKey(), stuPair.getValue());
			}
			builtIndex = true;
			System.out.println("Index Successfully Built");
		}
		catch (IOException ex) {
			System.out.println("Index not built due to IOException: " + ex.getMessage());
		}
	}
	
	/**
	 * Displays the created index made for a RandomAccessFile
	 * @param startingIndex
	 * @param endingIndex
	 * @return none
	 * @throws IOException
	 */
	public static void displayIndex (int startingIndex, int endingIndex) throws IOException {
		if (startingIndex == 0 && endingIndex == 36) {
			hashTable.print();
		}
		else {
			hashTable.print(startingIndex, endingIndex);
		}
	}
	
	/**
	 * Retrieves the record of a student whose ID matches the input ID
	 * @param studentID
	 * @return none
	 * @throws IOException
	 */
	public static void retrieveRecord (int studentID) throws IOException {
		try {
			Student stu = new Student();
			//Finds the address by searching for the studentID in the hash table
			//With how get is coded, studentID will get hashed and the hash value will be used to search
			Integer address = hashTable.get(studentID);
			//If the address isn't null, it means there is a key with the hash value
			if (address != null) {
				randFile.seek(address * RECSIZE);
				stu.readFromFile(randFile);
				System.out.println(stu);
			}
			else {
				System.out.println(studentID + " is an invalid ID");
			}
		}
		catch (IOException ex) {
			System.out.println("Record Retrieval failed due to " + ex.getMessage());
		}
	}
	
	/**
	 * Modifies the record of the student with a matching ID to the parameter ID
	 * @param studentID
	 * @return none
	 * @throws IOException
	 */
	public static void modifyRecord (int studentID) throws IOException {
		int selection = 0;
		try {
			//Same lines of code as retrieveRecord
			Student stu = new Student();
			Integer address = hashTable.get(studentID);
			if (address != null) {
				randFile.seek(address * RECSIZE);
				stu.readFromFile(randFile);
				printModOptions();
				while (selection != 4) {
					//Try-Catch block in case the user inputs an non-integer
					try {
						selection = keyboard.nextInt();
						//while loop that modifies the record until 4 is selected
						while (selection > 0 && selection < 4) {
							switch (selection) {
								case 1: //Change first name
									System.out.print("Enter first name: ");
									String firstN = keyboard.next();
									stu.setFirst(firstN);
									break;
									
								case 2: //Change last name
									System.out.print("Enter last name: ");
									String lastN = keyboard.next();
									stu.setLast(lastN);
									break;
									
								case 3: //Change GPA
									System.out.print("Enter GPA: ");
									double GPA = keyboard.nextDouble();
									stu.setGPA(GPA);
									break;
								
								case 4: //Done
									break;
							}
							printModOptions();
							selection = keyboard.nextInt();
						}
						//seek method is used here to seek back to the position of the record being modified
						//This is so the writeToFile method can overwrite the record being modifed rather than
						//add it at the end
						randFile.seek(address * RECSIZE);
						stu.writeToFile(randFile);
					}
					//Catch statement that catches if a non-integer input is used
					catch (InputMismatchException ex) {
						System.out.println("Input is not an integer. Please enter an integer");
						keyboard.nextLine();
						printModOptions();
						selection = 0;
					}
				}
			}
			else {
				System.out.println(studentID + " is an invalid ID");
			}
		}
		catch (IOException ex) {
			System.out.println("Record modification failed due to " + ex.getMessage());
		}
	}
	
	/**
	 * Adds a new record into the RandomAccessFile and into the binary tree
	 * @param fName
	 * @param lName
	 * @param studentID
	 * @param studentGPA
	 * @throws IOException
	 */
	public static void addRecord (String fName, String lName, int studentID, double studentGPA) throws IOException {
		Student newStudent = new Student();
		Integer address = hashTable.get(studentID);
		try {
			if (address != null) {
				System.out.println("This student ID already exists");
			}
			else {
				int position = (int) randFile.length();
				randFile.seek(position);
				newStudent.setData(fName, lName, studentID, studentGPA);
				newStudent.writeToFile(randFile);
				Pair<Integer, Integer> newStudentPair = new Pair<Integer, Integer>(studentID, position / RECSIZE);
				hashTable.put(newStudentPair.getKey(), newStudentPair.getValue());
			}
		}
		catch (IOException ex) {
			System.out.println("Adding Record failed due to " + ex.getMessage());
		}
	}
	
	/**
	 * Deletes a student record from the RandomAccessFile and from the binary tree via lazy deletion
	 * @param studentID
	 * @throws IOException
	 */
	public static void deleteRecord (int studentID) throws IOException {
		Integer address = hashTable.get(studentID);
		Student stu = new Student();
		try {
			if (address != null) {
				randFile.seek(address * RECSIZE);
				stu.readFromFile(randFile);
				stu.setFirst("DELETED");
				randFile.seek(address * RECSIZE);
				stu.writeToFile(randFile);
				hashTable.remove(studentID);
			}
			else {
				System.out.println("Student ID does not exist");
			}
		}
		catch (IOException ex) {
			System.out.println("Record Deletion failed due to " + ex.getMessage());
		}
	}

	private static void printModOptions() {
		System.out.println();
		System.out.println("1: Change First Name: ");
        System.out.println("2: Change Last Name: ");
        System.out.println("3: Change GPA: ");
        System.out.println("4: Finish");
        System.out.print("Enter your choice: ");
	}
}
