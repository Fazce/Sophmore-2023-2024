/**
 *  A linked data structure implementation of a binary search tree
 *
 *  @author COSC 311, Winter '24
 *  @version (2-22-24)
 */
package Nguyen_project4;

public class BST<E extends Comparable<E>> {
	
	// Class Node is defined as an inner class
	private static class Node <E> {
		
		// data stored in the node
		private E data;
		
		// reference to the root of the left and right subtrees
		private Node<E> left;
		private Node<E> right;
		
		/**
         * Construct a node with the given data value
         * @param item - The data value 
         */
		public Node(E item) {
			data = item;
			left = right = null;
		}
		
		/** 
		 * Return a string representing the node
		 * @param  None  
		 * @return a string representing the data stored in the node  	
		 */
		public String toString () {
			return data.toString();
		}
	}
	
	//data member
	private Node<E> root;
	
	
	/**
     * Construct an empty binary search tree 
     * @param none
     */
	public BST () {
		root = null;
	}
	

	/** 
	 * Search for an item in the tree
	 * @param  item  the target value
	 * @return true if item is found, and false otherwise
	 */
	public E find (E item) {
		Node<E> foundNode = find (root, item);
		return foundNode == null ? null: foundNode.data;
	}
	
	/** 
	 * Search for an item in the tree rooted at current
	 * @param  current  the current root
	 * @param  item  the target value
	 * @return true 
	 */
	private Node<E> find (Node<E> current , E item) {
		if (current == null)
			return null;
		int result = current.data.compareTo(item);
		if (result == 0)
			return current;
		else if (result < 0)
			return find (current.right, item);
		else
			return find (current.left, item);
	}
	
	/** 
	 * Insert an item to the tree
	 * @param  item  the value to be inserted 
	 * @return none 
	 */
	public void add(E item) {
		
			root =  add (root, item);
	}
	
	/** 
	 * Insert an item to the tree rooted at current
	 * @param  current  the current root
	 * @param  item  the value to be inserted 
	 * @return reference to the node that was inserted 
	 */
	private Node<E> add (Node <E>current , E item) {
		if (current == null) 
			current = new Node<>(item);
		else {
            int result = current.data.compareTo(item);
            if (result < 0)
                current.right =  add (current.right, item);
            else if (result > 0)
                current.left =  add (current.left, item);
		}
		return current;
	}
	
	/** 
	 * Traverse the tree using preorder traversal 
	 * @param  none
	 * @return none 
	 */
	public void preorder() {
		preorder (root, 1);
	}
	
	/** 
	 * Traverse the tree using preorder traversal 
	 * @param  current the current root
	 * @param  level the level of the current node
	 * @return none 
	 */
	private void preorder (Node<E> current, int level) {
		if (current != null) {
			for (int i = 1; i  < level; i++ )
				System.out.print("\t");
			System.out.println(current);
			preorder(current.left, level+1);
			preorder(current.right, level+1);
		}
	}
	
	/**
	 * Traverse the tree using breadth-first search or level-order traversal
	 * @param none
	 * @return none
	 */
	public void BFS(E item) {
		if (item == null) {
			BFS(root);
		}
		else {
			Node<E> startNode = find (root, item);
			BFS(startNode);
		}
	}
	
	/**
	 * Traverses the tree using breadth-first search or level-order traversal
	 * @param startNode, the node where the current Node is
	 * @return none
	 */
	private void BFS (Node<E> startNode) {
		QueueSLL<Node<E>> queue = new QueueSLL<>();
		int counter = 1;
		int buffer = 0;
		if (startNode == null) {
			return;
		}
		System.out.println(startNode);
		queue.offer(startNode);
		while (!queue.empty()) {
			if (counter == 0) {
				System.out.println();
				counter = buffer;
				buffer = 0;
			}
			Node<E> v = queue.remove();
			if (v.left != null) {
				System.out.print(v.left);
				System.out.print(" ");
				queue.offer(v.left);
				buffer++;
			}
			if (v.right != null) {
				System.out.print(v.right);
				System.out.print(" ");
				queue.offer(v.right);
				buffer++;
			}
			counter--;
		}
	}
	 
	/** 
	 * Return the smallest value in the tree 
	 * @param  none
	 * @return the smallest value 
	 */
	public E min () {
		return min(root);
	}

	/** 
	 * Return the smallest value in the tree  
	 * @param  current the current root
	 * @return the smallest value
	 */
	private E min (Node<E> current) {
		if (current.left == null)
			return current.data;
		else 
			return min(current.left);
	}
	
	/** 
	 * Delete a given item from the tree 
	 * @param  item the item to be deleted
	 * @return none
	 */
	public void delete (E item) {
		root = delete (root,item);
	}
	
	/** 
	 * Delete a given item from the tree 
	 * @param  current the current root
	 * @param  item the item to be deleted
	 * @return a reference to a node 
	 */
	private Node<E> delete(Node<E> current , E item) {
		if (current != null) {
			int result = current.data.compareTo(item);
			if (result < 0)
				current.right =  delete (current.right, item);
			else if (result > 0)
				current.left =  delete (current.left, item);	
			else {    // find it
				if (current.left == null)    // current has 1 child
					current = current.right;
				else if (current.right == null)  
					current = current.left;
				else {   // current has two children
					E replace = min(current.right);
					current.data = replace;
					current.right = delete(current.right, replace);	
				}
			}
		}
		return current;
	}	
	
	/** 
	 * Find and return the height of the tree 
	 * @param  none
	 * @return height of the tree
	 */
	public int height() {
		return height (root);
	}
	
	/** 
	 * Find and return the height of the tree 
	 * @param  root  the root of the tree
	 * @return height of the tree
	 */
	private int height (Node<E> current) {
		if (current == null) return 0;
		//int left = height(current.left);
		//int right = height(current.right);
		//System.out.println (left + "   " + right);
		
		//return 1 + (left > right ? left : right);
		return 1 + Math.max(height(current.left), height(current.right));
	}
	
	/**
     * check to see if the bst is empty
     * @param none
     * @return true if tree is empty, and false otherwise
     */
	public boolean empty () {
		return root == null;
	}
}

