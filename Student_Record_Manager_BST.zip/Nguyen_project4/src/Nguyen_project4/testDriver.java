/**
 * Programmer: Daniel Nguyen
 * Course: COSC 311, W '24
 * testDriver class for Project 4 where a student database is created via a menu driven program
 * The databases uses a Binary Search Tree to create an index for the student records
 */
package Nguyen_project4;

import java.io.*;
import java.util.*;

public class testDriver {
	//private static variables made within the class to be used in the class' methods
	private static Scanner keyboard = new Scanner (System.in);
	private static Scanner read;
	private static RandomAccessFile randFile;
	private static File file;;
	private static BST<Pair<Integer>> stuTree;
	private static final int RECSIZE = 92;
	private static boolean builtIndex = false;
	//Main method that initiates the program
	//try-catch block to catch if the user inputs a non-integer value for the menu
	public static void main(String[] args) throws IOException {
		heading();
		printMenu();
		int choice = 0;
		while (choice != 9) {
			try {
				choice = keyboard.nextInt();
				while (choice > 0 && choice < 9) {
					menuOptions(choice);
					printMenu();
					choice = keyboard.nextInt();
					if (choice < 0 || choice > 9) {
						System.out.println("Invalid option. Choose again");
						choice = keyboard.nextInt();
					}
				}
			}
			catch (InputMismatchException ex) {
				System.out.println("Not an integer. Please enter an integer: ");
				//nextLine() needed to skip to the next line and prevent the program from endlessly looping
				keyboard.nextLine();
				choice = 0;
			}
		}
	}
	/**
	 * Method that contains the handling of operations used in the program
	 * @param choice
	 * @return none
	 * @throws IOException
	 */
	public static void menuOptions (int choice) throws IOException {
		try {
			switch(choice) {
				case 1: //Build RandomAccessFile
					System.out.print("Enter an input file name: ");
					String fileNameInput = keyboard.next();
					file = new File (fileNameInput);
					read = new Scanner (file);
					System.out.print("Enter an output file name: ");
					String randomAFNameInput = keyboard.next();
					file = new File (randomAFNameInput);
					//Checks if a RandomAccessFile of the same name exists. Deletes the file if it does
					//Essentially acts as a way of overwriting a file of the same name
					if (file.exists()) {
						file.delete();
					}
					randFile = new RandomAccessFile (file, "rw");
					buildRandFile();
					break;
					
				case 2: //Display RandomAccessFile
					String randFileName;
					System.out.print("Enter the RandomAccessFile name: ");
					randFileName = keyboard.next();
					file = new File (randFileName);
					//Checks if the RandomAccessFile of the input name exist.
					//Displays the file if it exist. Else it asks the user to make the file
					if (file.exists()) {
						randFile = new RandomAccessFile (randFileName, "rw");
						displayRandFile();
						break;
					}
					else {
						System.out.println("Create the RandomAccessFile first");
						break;
					}
					
				case 3: //Build the index
					System.out.print("Enter the RandomAccessFile name: ");
					randFileName = keyboard.next();
					file = new File (randFileName);
					//Checks if the RandomAccessFile of the input name exist.
					//Creates an index for that file if it exist. Else it tells the user it doesn't exist
					if (file.exists()) {
						randFile = new RandomAccessFile (randFileName, "rw");
						buildIndex();
						break;
					}
					else {
						System.out.println("RandomAccessFile does not exist");
						break;
					}
					
				case 4: //Display the index
					if (builtIndex == false) {
						System.out.println("Build the index first!");
						break;
					}
					else {
						System.out.print("Enter the starting ID, or -1 to show the entire index: ");
						int startingID = keyboard.nextInt();
						displayIndex(startingID);
						break;
					}
					
				case 5: //Retrieve a record
					if (builtIndex == false) {
						System.out.println("Build the index first!");
						break;
					}
					else {
						System.out.print("Enter a student ID: ");
						int numID = keyboard.nextInt();
						retrieveRecord(numID);
						break;
					}
					
				case 6: //Modify a record
					if (builtIndex == false) {
						System.out.println("Build the index first!");
						break;
					}
					else {
						System.out.print("Enter a student ID: ");
						int studID = keyboard.nextInt();
						modifyRecord(studID);
						break;
					}
				
				case 7: //Add a new record
					if (builtIndex == false) {
						System.out.println("Build the index first!");
						break;
					}
					else {
						System.out.print("Enter first name: ");
						String fName = keyboard.next();
						System.out.print("Enter last name: ");
						String lName = keyboard.next();
						System.out.print("Enter student ID: ");
						int studentID = keyboard.nextInt();
						System.out.print("Enter GPA: ");
						double studentGPA = keyboard.nextDouble();
						addRecord(fName, lName, studentID, studentGPA);
						break;
					}
					
				case 8: //Delete a record
					if (builtIndex == false) {
						System.out.println("Build the index first!");
						break;
					}
					else {
						System.out.print("Enter a student ID: ");
						int stuID = keyboard.nextInt();
						deleteRecord(stuID);
					}
			}
		}
		catch (FileNotFoundException ex) {
			System.out.println(ex.getMessage());
		}
		catch (IOException ex) {
			System.out.println(ex.getMessage());
		}
	}
	
	/**
	 * Just a method to print out the heading
	 * @param none
	 * @return none
	 */
	public static void heading() {
 		System.out.println("Programmer:        Daniel Nguyen");
 		System.out.println("Course:            COSC 311, W '24	");
 		System.out.println("Project:           4");
 		System.out.println("Due date:          4-2-24\n");
 	}
	
	/**
	 * Prints the menu options of the program in the console
	 * @param none
	 * @return none
	 */
	public static void printMenu() {
        System.out.println("\n   Menu   ");
        System.out.println("   ====");
        System.out.println("1: Make a random-access file");
        System.out.println("2: Display a random-access file");
        System.out.println("3: Build the index");
        System.out.println("4: Display the index");
        System.out.println("5: Retrieve a record");
        System.out.println("6: Modify a record");
        System.out.println("7: Add a new record");
        System.out.println("8: Delete a record");
        System.out.println("9: Exit");
        
        System.out.print("\nEnter your choice: ");
    }
	
	/**
	 * Creates a new RandomAccessFile when called to, assuming that a text file exists
	 * @param none
	 * @return none
	 * @throws IOException
	 */
	public static void buildRandFile() throws IOException {
		Student stu = new Student();
		while (read.hasNext()) {
			stu.readFromTextFile(read);
			stu.writeToFile(randFile);
		}
		System.out.println("RandomAccessFile successfully created");
	}
	
	/**
	 * Displays a RandomAccessFile when called to if the RandomAccessFile exists
	 * @param none
	 * @return none
	 * @throws IOException
	 */
	public static void displayRandFile() throws IOException {
		Student stu = new Student();
		int counter = 0;
		try {
			//Starts at the beginning of the file
	        randFile.seek(0);
	        //Searches until the end of the file
	        while (randFile.getFilePointer() < randFile.length()) {
	            stu.readFromFile(randFile);
	            //Checks if a record as been "deleted". Prints the record if it isn't
	            if (!stu.getFirst().trim().equals("DELETED")) {
	                System.out.println(stu);
	                counter++;
	            }
	            //if counter reaches five, stop printing records and asks for options
	            //If N is entered, reset counter to 5
	            if (counter == 5) {
	                System.out.print("Enter N (for next five records), A for all remaining records, or M for main menu: ");
	                String choice = keyboard.next();
	                if (choice.toUpperCase().equals("N")) {
	                    counter = 0;
	                }
	                //If A is entered, just have the loop continue 
	                else if (choice.toUpperCase().equals("A")) {
	                    while (randFile.getFilePointer() < randFile.length()) {
	                        stu.readFromFile(randFile);
	                        if (!stu.getFirst().trim().equals("DELETED")) {
	                            System.out.println(stu);
	                        }
	                    }
	                    break;
	                }
	                else {
	                    break;
	                }
	            }
	        }
	    }
	    catch (IOException ex) {
	        System.out.println("Display RandomAccessFile failed due to IOException: " + ex.getMessage());
	    }
	}
	
	/**
	 * Method that builds a Binary-Search-Tree index for a RandomAccessFile
	 * @param none
	 * @return none
	 * @throws IOException
	 */
	public static void buildIndex () throws IOException {
		Student stu = new Student();
		stuTree = new BST<Pair<Integer>>();
		try {
			randFile.seek(0);
			while (randFile.getFilePointer() < randFile.length()) {
				int position = (int) randFile.getFilePointer();
				stu.readFromFile(randFile);
				//If statement to check if the end of the file is reached
				if (stu.getFirst() == null) {
					break;
				}
				//Else if statement that checks if a record is deleted. If so, do not add it in the index and continue
				//Will only be reached if running the program a second time with a RandomAccessFile containing a deleted record
				else if (stu.getFirst().trim().equals("DELETED")){
					continue;
				}
				//Adds the student into the binary tree
				Pair<Integer> stuPair = new Pair<Integer>(stu.getID(), position / RECSIZE);
				stuTree.add(stuPair);
			}
			builtIndex = true;
			System.out.println("Index Sucessfully Built");
		}
		catch (IOException ex) {
	        System.out.println("Index not built due to IOException: " + ex.getMessage());
	    }
	}
	
	/**
	 * Displays the created index made for a RandomAccessFile
	 * @param startingID
	 * @return none
	 * @throws IOException
	 */
	public static void displayIndex (int startingID) throws IOException {
		//Creates a pair containing the studentID
		//Create another pair to hold the pair of that studentID in the tree
		Pair<Integer> searchID = new Pair<Integer>(startingID, null);
		Pair<Integer> foundID = stuTree.find(searchID);
		//Prints the entire binary tree in level-order traversal
		if (startingID == -1) {
			stuTree.BFS(null);
		}
		//Prints the binary tree starting from the studentID entered in the method, assuming it exists in the tree
		else if (foundID != null){
			stuTree.BFS(foundID);
		}
		else {
			System.out.println(startingID + " is an invalid ID");
		}
	}
	
	/**
	 * Retrieves the record of a student whose ID matches the input ID
	 * @param numID
	 * @return none
	 * @throws IOException
	 */
	public static void retrieveRecord (int numID) throws IOException {
		try {
			Student stu = new Student();
			//First Pair is for the pair containing the sentID
			//Second pair is to check if the binary tree contains the ID
			Pair<Integer> sentID = new Pair<Integer>(numID, null);
			Pair<Integer> found = stuTree.find(sentID);
			//if found isn't null, it means it exists
			if (found != null) {
				//Gets the address of the found student ID
				int position = found.getSecond();
				//Seeks the ID in the randomAccessFile by using its address
				randFile.seek(position * RECSIZE);
				stu.readFromFile(randFile);
				System.out.println(stu);
			}
			else {
				System.out.println(numID + " is an invalid ID");
			}
		}
		catch (IOException ex) {
			System.out.println("Record Retrieval impossible due to IOException: " + ex.getMessage());
		}
	}
	
	/**
	 * Modifies the record of the student with a matching ID to the parameter ID
	 * @param studID
	 * @return none
	 * @throws IOException
	 */
	public static void modifyRecord (int studID) throws IOException {
		int selection = 0;
		try {
			//The same lines of code from retrieveRecord
			Student stu = new Student();
			Pair<Integer> sentID = new Pair<Integer>(studID, null);
			Pair<Integer> found = stuTree.find(sentID);
			if (found != null) {
				int position = found.getSecond();
				randFile.seek(position * RECSIZE);
				stu.readFromFile(randFile);
				printModOptions();
				selection = keyboard.nextInt();
				//while loop that modifies the record until 4 is selected
				while (selection > 0 && selection < 4) {
					switch (selection) {
						case 1: //Change first name
							System.out.print("Enter first name: ");
							String firstN = keyboard.next();
							stu.setFirst(firstN);
							break;
							
						case 2: //Change last name
							System.out.print("Enter last name: ");
							String lastN = keyboard.next();
							stu.setLast(lastN);
							break;
							
						case 3: //Change GPA
							System.out.print("Enter GPA: ");
							double GPA = keyboard.nextDouble();
							stu.setGPA(GPA);
							break;
						
						case 4: //Done
							break;
					}
					printModOptions();
					selection = keyboard.nextInt();
				}
				//seek method is used here to seek back to the position of the record being modified
				//This is so the writeToFile method can overwrite the record being modifed rather than
				//add it at the end
				randFile.seek(position * RECSIZE);
				stu.writeToFile(randFile);
			}
			else {
				System.out.println(studID + " is an invalid ID");
			}
		}
		catch (InputMismatchException ex) {
			System.out.println("Not an integer. Please enter an integer: ");
			//nextLine() needed to skip to the next line and prevent the program from endlessly looping
			keyboard.nextLine();
			selection = keyboard.nextInt();
		}
		catch (IOException ex) {
			System.out.println("Record Modification can't be done due to IOException: " + ex.getMessage());
		}
	}
	
	/**
	 * Adds a new record into the RandomAccessFile and into the binary tree
	 * @param fName
	 * @param lName
	 * @param studentID
	 * @param studentGPA
	 * @throws IOException
	 */
	public static void addRecord (String fName, String lName, int studentID, double studentGPA) throws IOException {
		//Pairs used to find the studentID in the binary tree
		Pair<Integer> searchID = new Pair<Integer>(studentID, null);
		Pair<Integer> foundID = stuTree.find(searchID);
		try {
			//If the studentID exists, does not add the record
			if (foundID != null) {
				System.out.println("Student ID already exists");
			}
			else {
				//Gets the position at the end of the file
				int position = (int) randFile.length();
				randFile.seek(position);
				Student newStudent = new Student(); 
				//Creates a new student and add them into the file and binary tree
				newStudent.setData(fName, lName, studentID, studentGPA);
				newStudent.writeToFile(randFile);
				Pair<Integer> newStu = new Pair<Integer>(studentID, position / RECSIZE);
				stuTree.add(newStu);
			}
		}
		catch (IOException ex) {
			System.out.println("Adding record failed due to " + ex.getMessage());
		}
	}
	
	/**
	 * Deletes a student record from the RandomAccessFile and from the binary tree via lazy deletion
	 * @param stuID
	 * @throws IOException
	 */
	public static void deleteRecord (int stuID) throws IOException {
		//Pairs to find the studentID in the binary tree
		Pair<Integer> searchID = new Pair<Integer>(stuID, null);
		Pair<Integer> foundID = stuTree.find(searchID);
		Student stu = new Student();
		try {
			if (foundID != null) {
				//Gets the position of the student in the file
				int position = foundID.getSecond();
				randFile.seek(position * RECSIZE);
				stu.readFromFile(randFile);
				//Deletes the student from the file and binary tree
				stu.setFirst("DELETED");
				randFile.seek(position * RECSIZE);
				stu.writeToFile(randFile);
				stuTree.delete(foundID);
			}
			else {
				System.out.println(stuID + " does not exists");
			}
		}
		catch (IOException ex) {
			System.out.println("Record deletion failed due to " + ex.getMessage());
		}
	}
	
	/**
	 * Prints the list of modification options when modifying a student record
	 */
	private static void printModOptions() {
		System.out.println();
		System.out.println("1: Change First Name: ");
        System.out.println("2: Change Last Name: ");
        System.out.println("3: Change GPA: ");
        System.out.println("4: Finish");
        System.out.print("Enter your choice: ");
	}
}
